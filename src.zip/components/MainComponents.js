import React from 'react'

const MainComponents = () => {
  return (
    <div className="bg-pink-300">MainComponents</div>
  )
}

export default MainComponents