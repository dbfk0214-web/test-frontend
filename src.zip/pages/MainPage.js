import React from 'react'
import MainComponents from '../components/MainComponents'

const MainPage = () => {
  return (
    <div className='bg-pink-300'><MainComponents/></div> 
  )
}

export default MainPage